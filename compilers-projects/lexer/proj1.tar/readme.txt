To run this program, simply run make in your shell.
